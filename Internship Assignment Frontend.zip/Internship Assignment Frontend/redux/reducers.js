const initialState = {
    columns: [
        {
            id: 1,
            title: 'Not started',
            cards: [
                { id: 1, title: 'Card 1' },
                { id: 2, title: 'Card 4' },
                { id: 3, title: 'Card 5' },
            ],
        },
        {
            id: 2,
            title: 'In progress',
            cards: [
                { id: 4, title: 'Card 2' },
            ],
        },
        {
            id: 3,
            title: 'Completed',
            cards: [
                { id: 5, title: 'Card 3' },
            ],
        },
    ],
};

export const tasksReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'CREATE_CARD': {
            const column = action.payload.column;
            const newCard = { id: Date.now(), title: 'New Card' };
            column.cards.push(newCard);
            return { ...state, columns: [...state.columns] };
        }

        case 'UPDATE_CARD_COUNT': {
            const column = action.payload;
            return { ...state, columns: [...state.columns] };
        }

        default:
            return state;
    }
};

export const createNewCard = (column) => ({
    type: 'CREATE_CARD',
    payload: { column },
});

export const updateCardCount = (column) => ({
    type: 'UPDATE_CARD_COUNT',
    payload: column,
});