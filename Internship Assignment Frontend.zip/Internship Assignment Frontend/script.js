let draggedCard;

function dragStart(event) {
    draggedCard = event.target;
    event.dataTransfer.setData('text/plain', null);
}

function dragOver(event) {
    event.preventDefault();
}

function updateCardCount() {
    const cardCounts = document.querySelectorAll('.card-count');
    const columns = document.querySelectorAll('.column');
    columns.forEach((column, index) => {
        const cards = column.querySelectorAll('.card');
        cardCounts[index].textContent = cards.length;
    });
}